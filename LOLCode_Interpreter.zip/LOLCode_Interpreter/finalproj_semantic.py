from finalproj_syntax import Parser, operations, literals, createSymTable, printSymTable
from finalproj import readFile, tokenize 

arithmetic_operations = ["SUM_OF", "DIFF_OF", "PRODUKT_OF", "QUOSHUNT_OF", "MOD_OF"]
boolean_operations = ["BOTH_OF", "EITHER_OF", "WON_OF", "NOT", "ALL_OF", "ANY_OF"]
mathematical_operations = ["BIGGR_OF", "SMALLR_OF"]
comparison_operations = ["BOTH_SAEM", "DIFFRINT"]
relational_operations = ["BIGGR_OF", "SMALLR_OF", "BOTH_SAEM", "DIFFRINT"]

class SemanticAnalyzer:
    """
    SemanticAnalyzer class
        Performs semantic analysis on the abstract syntax tree(AST) from the Parser class. 
        It updates the symbol table and checks for errors and warnings.
    """
    def __init__(self, ast, symbol_table, input_calls=None, print_to_console=None):
        self.ast = ast
        self.symbol_table = symbol_table
        self.errors = []
        self.warnings = []
        self.visible_output = []
        self.input_calls = input_calls
        self.print_to_console = print_to_console
        self.numeric_types = ["NUMBR", "NUMBAR"]

    def get_variable(self, var_name):
        """
        Gets variable from symbol table
        """

        return self.symbol_table.get(var_name, {'type': "UNDECLARED", 'value': None})


    def analyze_expr(self, node):
        """
        Analyzes the expression node in the AST (Literal, Variable, Operation, etc.) recursively.
        This fucntion returns the type of the expression node (NUMBR, NUMBAR, ERROR, etc.)
        """

        # if node is a literal
        if node[0] in ["NUMBR", "NUMBAR", "YARN", "TROOF"]:
            return node[0]

        # if node is variable
        if node[0] == "Variable":
            var_name = node[1]
            data = self.get_variable(var_name)
            
            if data["type"] == "UNDECLARED":
                self.errors.append(f"Error: Undefined variable '{var_name}'.")
                return "ERROR"
            if data["type"] == "NOOB":
                self.warnings.append(f"Warning: '{var_name}' used before assignment (NOOB).")
                return "NUMBR" 
            return data["type"]
        
        # if node is operation
        if node[0] in self.arithmetic_operations:
            leftType = self.analyze_expr(node[1])
            rightType = self.analyze_expr(node[2])

            if leftType == "ERROR" or rightType == "ERROR":
                return "ERROR"
            
            if leftType not in self.numeric_types or rightType not in self.numeric_types:
                self.errors.append(f"Arithmetic type error in {node[0]}: expected numeric operands.")
                return "ERROR"

            if leftType == "NUMBAR" or rightType == "NUMBAR":
                return "NUMBAR"

            return "NUMBR"
        
        return "UNKNOWN"
    

    def comparison_op_checker(self, op_node):
        """
        Checks if the types are valid for comparison or relational operations.
        Returns the type of the operation (TROOF, NUMBAR, ERROR)
        """

        operation = op_node[0] # name of operation
        left = self.analyze_expr(op_node[1]) # left
        right = self.analyze_expr(op_node[2]) # right

        #if op1 or op2 is error, return error
        if left == "ERROR" or right == "ERROR":
            return "ERROR"
        
        #BOTH SAEM and DIFFRINT return TROOF
        if operation in comparison_operations:
            return "TROOF"
        
        #BIGGR OF and SMALLR of should return NUMBAR
        if operation in mathematical_operations:
            if left not in self.numeric_types:
                self.errors.append(f"Error in '{operation}': First operand (Type: {left}) must be numeric.")
                return "ERROR"
            
            if right not in self.numeric_types:
                self.errors.append(f"Error in '{operation}': Second operand (Type: {right}) must be numeric.")
                return "ERROR"
            
            if left == "NUMBR" or right == "NUMBR":
                return "NUMBR"
            return "NUMBAR"
        
        return "ERROR"
    
    def explicit_typecastinng(self, item, target_type):
        """
        Casts item to target_type.
        Returns new dict {type, value} or ERROR.
        """
        curr_type = item["type"]
        val = item["value"]

        # if types are the same, return copy
        if curr_type == target_type:
            return item.copy()

        # cast to numbr
        if target_type == "NUMBR":
            if curr_type == "NUMBAR":
                return {"type": "NUMBR", "value": int(val)}
            elif curr_type == "YARN":
                try:
                    return {"type": "NUMBR", "value": int(val)}
                except ValueError:
                    return {"type": "ERROR", "value": None} # cannot be typecast 
            elif curr_type == "TROOF":
                return {"type": "NUMBR", "value": 1 if val else 0}
            elif curr_type == "NOOB":
                return {"type": "NUMBR", "value": 0}

        # cast to numbar
        elif target_type == "NUMBAR":
            if curr_type == "NUMBR":
                return {"type": "NUMBAR", "value": float(val)}
            elif curr_type == "YARN":
                try:
                    return {"type": "NUMBAR", "value": float(val)}
                except ValueError:
                    return {"type": "ERROR", "value": None} # cannot be typecast if 
            elif curr_type == "TROOF":
                return {"type": "NUMBAR", "value": 1.0 if val else 0.0}
            elif curr_type == "NOOB":
                return {"type": "NUMBAR", "value": 0.0}

        # cast to yarn
        elif target_type == "YARN":
            if curr_type == "NUMBR" or curr_type == "NUMBAR":
                return {"type": "YARN", "value": str(val)}
            elif curr_type == "TROOF":
                return {"type": "YARN", "value": "WIN" if val else "FAIL"}
            elif curr_type == "NOOB":
                return {"type": "YARN", "value": ""} # casting NOOB to string returns empty string

        # cast to troof
        elif target_type == "TROOF":
            if curr_type == "NUMBR":
                return {"type": "TROOF", "value": val != 0}
            elif curr_type == "NUMBAR":
                return {"type": "TROOF", "value": val != 0.0}
            elif curr_type == "YARN":
                return {"type": "TROOF", "value": len(val) > 0}
            elif curr_type == "NOOB":
                return {"type": "TROOF", "value": False}

        # cast to noob
        elif target_type == "NOOB":
            return {"type": "NOOB", "value": None}

        self.errors.append(f"Error: Cannot cast type {curr_type} to {target_type}")
        return {"type": "ERROR", "value": None}
    
    def implicit_typecasting_numeric(self, item):
        """
        Performs implicit typecasting to a numeric type, NUMBR and NUMBAR.
        """

        get_type = item["type"]
        get_value = item["value"]
        
        # NOOB = 0
        if get_type == "NOOB":
            self.warnings.append(f"Warning: NOOB used in numeric context, implicitly cast to NUMBR 0.")
            return {"type": "NUMBR", "value": 0}

        # NUMBR: Value should be a Python int
        if get_type == "NUMBR":
            # Ensure it's a pure Python int, in case it was stored as 4.0
            return {"type": "NUMBR", "value": int(get_value)} 

        # NUMBAR: Value should be a Python float
        if get_type == "NUMBAR":
            # Ensure it's a pure Python float
            return {"type": "NUMBAR", "value": float(get_value)}

        # TROOF (WIN = 1, FAIL = 0)
        if get_type == "TROOF":
            return {
                "type": "NUMBR",
                "value": 1 if get_value is True else 0
            }

        # YARN conversion
        if get_type == "YARN":
            s = str(get_value).strip()

            # empty string = 0
            if s == "":
                self.warnings.append(f"Warning: Empty YARN used in numeric context, implicitly cast to NUMBR 0.")
                return {"type": "NUMBR", "value": 0}

            # Attempt YARN TO NUMBAR (which handles both integers and floats)
            try:
                float_value = float(s)
                
                # Check if the float value is actually an integer (e.g., 4.0)
                if float_value == int(float_value):
                    # Return NUMBR (integer) if no decimal was explicitly used
                    return {"type": "NUMBR", "value": int(float_value)}
                else:
                    # Return NUMBAR (float)
                    return {"type": "NUMBAR", "value": float_value}
                    
            except ValueError:
                # The YARN is not a valid numeric string
                self.errors.append(f"Invalid numeric cast from YARN '{s}'.")
                return {"type": "ERROR", "value": None}

        return {"type": "ERROR", "value": None}
    
    def implicit_typecasting_troof(self, item):
        """
        typecasts into TROOF (boolean)
        """

        result = "WIN"

        if item is None:
            return {"type": "TROOF", "value": "FAIL"}
        
        get_type = item["type"]
        get_value = item["value"]

        # NOOB = FAIL
        if get_type == "NOOB":
            result = "FAIL"

        # TROOF as is
        elif get_type == "TROOF":
            result = "WIN" if get_value in [True, "WIN"] else "FAIL"
        
        # NUMBR and NUMBAR 0, 0.0
        elif get_type in self.numeric_types:
            result = "FAIL" if float(get_value) == 0.0 else "WIN"

        # YARN empty string
        elif get_type == "YARN":
            result = "FAIL" if get_value == "" else "WIN"

        return {"type": "TROOF", "value": result}
    
    def is_equal(self, left, right):

        left_type = left["type"]
        left_value = left["value"]
        right_type = right["type"]
        right_value = right["value"]

        if left_type == "NOOB" or right_type == "NOOB":
            return (left_type == "NOOB" and right_type == "NOOB")
        
        if left_type == right_type:
            return left_value == right_value
        
        if left_type in self.numeric_types and right_type in self.numeric_types:
            if left_type == "NUMBR" and right_type == "NUMBR":
                return int(left_value) == int(right_value)
            return float(left_value) == float(right_value)
        
        return False
    
    def analyze_loop(self, loop_node):
        """
        Analyzes loops and increment conditions
        """
        _, loop_name, loop_direction, loop_var_token, condition_type, condition_expr, loop_body = loop_node

        increment = 0
        if loop_direction == "UPPIN_YR":
            increment = 1
        elif loop_direction == "NERFIN_YR":
            increment = -1

        if isinstance(loop_var_token, tuple):
            var_name = loop_var_token[1]
        else:
            var_name = loop_var_token

        # ensure variable declared
        if var_name not in self.symbol_table:
            self.errors.append(f"Error: Loop variable '{var_name}' undeclared.")
            return

        # avoid infinite loops
        max_iters = 10000
        iters = 0

        while True:
            # evaluate the condition expression 
            condition_val = self.evaluate_expr_stack(condition_expr)

            if condition_val["type"] == "ERROR":
                self.errors.append("Error: invalid loop condition.")
                return
            
            else:
                self.symbol_table["IT"]["type"] = condition_val["type"]
                self.symbol_table["IT"]["value"] = condition_val["value"]

            # convert condition_val to boolean
            if condition_val["type"] == "TROOF":
                is_true = bool(condition_val["value"])
            elif condition_val["type"] in ["NUMBR", "NUMBAR"]:
                is_true = float(condition_val["value"]) != 0.0
            elif condition_val["type"] == "YARN":
                is_true = condition_val["value"] != ""
            else:
                is_true = False

            if condition_type == "WILE":
                # WILE (WHILE True)
                # Break if the condition is FALSE.
                if not is_true:
                    break
            
            elif condition_type == "TIL":
                # TIL (UNTIL True)
                # Break if the condition is TRUE.
                if is_true:
                    break

            self.analyze_statements(loop_body)

            var_data = self.symbol_table.get(var_name)
            if not var_data:
                self.errors.append(f"Error: Loop variable '{var_name}' missing from symbol table.")
                return

            typecasted_data = self.implicit_typecasting_numeric(var_data)
            
            if typecasted_data["type"] == "ERROR":
                self.errors.append(f"Runtime Error: Cannot use {loop_direction} on non-numeric value in '{var_name}'.")
                return
            
            old_val = typecasted_data["value"]
            
            # determine the result type based on what the value was cast to.
            final_type = typecasted_data["type"] 
            
            new_val = old_val + increment
            
            # update the Symbol Table
            if final_type == "NUMBAR":
                # use NUMBAR if it was originally NUMBAR or implicitly cast to NUMBAR
                self.symbol_table[var_name]["value"] = float(new_val)
                self.symbol_table[var_name]["type"] = "NUMBAR"
            else:
                # force to integer for NUMBR
                self.symbol_table[var_name]["value"] = int(new_val)
                self.symbol_table[var_name]["type"] = "NUMBR"
            
            iters += 1
            if iters > max_iters:
                self.errors.append("Infinite loop: iteration limit reached.")
                break

    def analyze_conditional(self, stmt):
        """
        Analyzes a conditional statement (no MEBBE yet)
        """
        conditional_data = stmt[1]
        
        #check IT current value       
        it_info = self.get_variable("IT")
        item = it_info

        #typecast into boolean 
        get_type = item.get("type")
        get_value = item.get("value")
        
        is_true = self.implicit_typecasting_troof(item)["value"] == "WIN"

        ya_rly_block = None
        no_wai_block = None
        
        #get YA RLY(if) and NO WAI(else) blocks
        for part in conditional_data[1:]:
            if part[0] == "YA RLY":
                ya_rly_block = part[1]
            elif part[0] == "NO WAI":
                no_wai_block = part[1]

        #flag to check if a block was executed
        executed_block = False
        
        #check if YA RLY is true
        if is_true and ya_rly_block:
            self.analyze_statements(ya_rly_block)   #if true, analyze statements in ya rly block
            executed_block = True                   #then, execute
            
        #check if YA RLY is false and no_wai_block exists
        if not executed_block and no_wai_block:
            self.analyze_statements(no_wai_block)   #analyze statements in no wai block

    
    def analyze_functiondef(self,node):
        # get name, parameters, statement and return value
        func_name = node[1][0]
        params = node[1][1]
        statements = node[1][2]
        return_val = node[1][3]
        
        # add to symbol table
        self.symbol_table[func_name] = {
            "type": "FUNCTION",
            "params": params,
            "body": statements,       
            "return": return_val 
        }

    def analyze_switch_case(self, switch_node):

        _, code_blocks, omgwtf_block = switch_node

        it_data = self.get_variable("IT")

        #convert to literal
        if it_data["type"] in ["NUMBR", "NUMBAR"]:
            it_literal = self.implicit_typecasting_numeric(it_data)

        elif it_data["type"] == "TROOF":
            it_literal = {"type": "TROOF", "value": it_data["value"]}

        # convert yarn 
        elif it_data["type"] == "YARN":
            s = str(it_data["value"]).strip()

            try:
                it_literal = {"type": "NUMBR", "value": int(s)}
            except ValueError:
                try:
                    it_literal = {"type": "NUMBAR", "value": float(s)}
                except ValueError:
                    it_literal = {"type": "YARN", "value": s}

        elif it_data["type"] == "NOOB":
            it_literal = {"type": "NOOB", "value": None}

        else:
            self.errors.append(f"Error: Invalid IT type '{it_data['type']}'")
            return
        
        #flag for checking if IT matches a case
        is_match = False

        #evaluate each case block (OMG)
        for case_type, case_val_literal, stmts, with_gtfo in code_blocks:

            #convert back
            if case_type == "NUMBR":
                case_val_eval = {"type": "NUMBR", "value": int(case_val_literal)}

            elif case_type == "NUMBAR":
                case_val_eval = {"type": "NUMBAR", "value": float(case_val_literal)}

            elif case_type == "TROOF":
                case_val_eval = {"type": "TROOF", "value": (case_val_literal == "WIN")}

            elif case_type == "YARN":
                case_val_eval = {"type": "YARN", "value": case_val_literal.strip('"')}

            else:
                self.errors.append(f"Error: Invalid case type '{case_type}' in OMG.")
                continue
            
            #if yarn is equal to numbr or numbar
            if it_literal["type"] == "YARN" and case_val_eval["type"] in ["NUMBR", "NUMBAR"]:
                try:
                    it_literal = self.implicit_typecasting_numeric(it_literal)
                except Exception:
                    self.errors.append(f"Error: Cannot cast IT '{it_literal['value']}' to numeric for comparison.")
                    continue

            #check if IT and case value are equal
            equal = self.is_equal(it_literal, case_val_eval)

            #if IT and case value are equal
            if equal:
                is_match = True
                self.analyze_statements(stmts)

                #break if gtfo encountered
                if with_gtfo:
                    break

        #go to default block (OMGWTF) if IT does not match any case
        if not is_match and omgwtf_block is not None:
            _, stmt_list = omgwtf_block
            self.analyze_statements(stmt_list)
        
    def evaluate_expr_stack(self, node):
        """
        Evaluates the expression node in the AST using 2 stacks. The 'stack' holds the nodes and 
        operator markers (e.g. "DO_OPERATION", "DO_SMOOSH", etc.). The 'eval_stack' holds the 
        evaluated literals, variables, operations, etc.
        
        When an operator marker is evaluated, the 'eval_stack' pops the operands and
        performs the operation. After, the result is pushed to the 'eval_stack'.

        It handles the evaluation of:
            literals
            variables
            arithmetic operations
            boolean (and multi boolean) operations
            concatenation
            comparison (and relational) operations
        """

        stack = [node]

        eval_stack = []  # stack where evaluated values go

        while stack:
            current = stack.pop() # LIFO

            if current[0] in ["NUMBR", "NUMBAR", "YARN", "TROOF"]:
                type_ = current[0]
                val = current[1]

                #LITERALS
                if type_ == "NUMBR": 
                    val = int(val)
                if type_ == "NUMBAR": 
                    val = float(val)
                if type_ == "TROOF": 
                    val = (val == "WIN")
                if type_ == "YARN":
                    if len(val) >= 2 and val.startswith('"') and val.endswith('"'):
                        val = val[1:-1]

                # push literal to eval_stack
                eval_stack.append({"type": type_, "value": val})
                continue

            #VARIABLE
            if current[0] == "Variable":
                var_name = current[1]
                data = self.get_variable(var_name)

                if data["type"] == "UNDECLARED":
                    self.errors.append(f"Error: Undefined variable '{var_name}'.")
                    return {"type": "ERROR", "value": None}

                if data["type"] == "NOOB":
                    eval_stack.append({"type": "NOOB", "value": None})
                    continue
                else:
                    eval_stack.append({"type": data["type"], "value": data["value"]})
                continue
            
            #ARITHMETIC OPERATIONS
            if current[0] in arithmetic_operations:
                # push operands to stack first
                stack.append(("DO_OPERATION", current[0]))  # marker so we can apply operation later
                stack.append(current[2])
                stack.append(current[1])
                continue

            #MATHEMATICAL OPERATIONS
            if current[0] in mathematical_operations:
                stack.append(("MATH_OPERATION", current[0]))  # marker so we can apply operation later
                stack.append(current[2])
                stack.append(current[1])
                continue
            
            #BOOLEAN OPERATIONS
            if current[0] in boolean_operations:
                if current[0] in ["ANY_OF", "ALL_OF"]:
                    operands = current[1:]
                    
                    stack.append(("MULTI_BOOL_OPERATION", current[0],len(operands)))
                    
                    # push to stack to pop in reverse(start from end)
                    for expr in reversed(operands):
                        stack.append(expr)


                if current[0] in ["BOTH_OF", "EITHER_OF", "WON_OF"]:
                    stack.append(("BOOL_OPERATION", current[0]))  # marker so we can apply operation later
                    stack.append(current[1])
                    stack.append(current[2])
                
                elif current[0] == "NOT":
                    stack.append(("BOOL_OPERATION", current[0]))  # marker so we can apply operation later
                    stack.append(current[1])
                
                
                continue
            
            #CONCATENATION
            if current[0] == "SMOOSH":
                operands = current[1:] # get all variables/strings to be put in SMOOSH

                stack.append(("DO_SMOOSH", len(operands)))
                for expr in reversed(operands):
                    stack.append(expr)
                continue
            
            #COMPARISON OPERTIONS
            if current[0] in comparison_operations:
                stack.append(("DO_COMPARE", current[0]))
                stack.append(current[2])  
                stack.append(current[1])
                continue

            # FUNCTION CALL
            if current[0] == "FUNCTION_CALL":
                name = current[1][0]
                args = current[1][1]
                
                # get the contents of function being used
                function = self.symbol_table.get(name)

                if not function:
                    # if not declared in symbol table, return error
                    self.errors.append(f"Error: Function '{name}' is undefined.")
                    return {"type": "ERROR", "value": None}
                
                if function["type"] != "FUNCTION":
                    # if variable/name is not function, return error
                    self.errors.append(f"Error: '{name}' is not a function.")
                    return {"type": "ERROR", "value": None}
                                
                params = function["params"]
                body = function["body"]
                return_val = function["return"]

                if len(params) != len(args):
                    # if number of args and parameters are not equal. return error
                    self.errors.append(f"Error: Expects {len(params)} arguments, got {len(args)}.")
                    return {"type": "ERROR", "value": None}
                
                final_args = []
                # execute expression in arguments first
                for arg in args:
                    if arg[0] == "Variable":
                        var_name = arg[1]
                        # check if variable in arg is declared in symbol table
                        if var_name not in self.symbol_table:
                            print(self.errors)
                            self.errors.append(f"Error: Argument '{var_name}' is undefined.")
                            return {"type": "ERROR", "value": None} 
                    val = self.evaluate_expr_stack(arg)
                    
                    if val["type"] =="ERROR":
                        return {"type": "ERROR", "value": None}
                    
                    final_args.append(val)

                # make copy of symbol table from main running program
                main_symbol_table = self.symbol_table.copy()
                
                # put arguments in symbol table
                for i in range(len(params)):
                    self.symbol_table[params[i]] = final_args[i].copy()

                # execute the body of function
                self.analyze_statements(body)

                # default return value
                self.symbol_table["IT"] = {"type": "NOOB", "value": None}
                result = {"type": "NOOB", "value": None}
                
                if return_val != "NOOB":
                    ret = self.evaluate_expr_stack(return_val)
                    if ret["type"] != "ERROR":
                        result = ret
                
                # return symbol to be the one from main before the adding of function params
                self.symbol_table = main_symbol_table

                # update IT
                self.symbol_table["IT"] = result.copy()

                eval_stack.append(result)
                continue                


            if current[0] == "MAEK":
                expr = current[1]
                target_type = current[2]
                
                stack.append(("DO_MAEK", target_type))
                stack.append(expr)
                continue
            
            if current[0] == "DO_MAEK":
                target_type = current[1] # get target type

                # the value to be typecasted
                value = eval_stack.pop()

                if value["type"] == "ERROR":
                    return {"type": "ERROR", "value": None}

                # Perform cast
                casted_result = self.explicit_typecastinng(value, target_type)
                
                eval_stack.append(casted_result)
                continue

            # compute
            if current[0] == "DO_OPERATION":
                op = current[1]

                # pop from stack
                right = eval_stack.pop()
                left = eval_stack.pop()

                if left["type"] == "ERROR" or right["type"] == "ERROR":
                    return {"type": "ERROR", "value": None}
                
                # orig types
                orig_left = left["type"]
                orig_right = right["type"]

                # type checking
                left = self.implicit_typecasting_numeric(left)
                right = self.implicit_typecasting_numeric(right)

                if left["type"] == "NUMBAR" or right["type"] == "NUMBAR":
                    finalType = "NUMBAR"
                else:
                    # check if the original types
                    if orig_left == "NUMBAR" or orig_right == "NUMBAR":
                        finalType = "NUMBAR"
                    else:
                        finalType = "NUMBR"

                if finalType == "NUMBAR":
                    lval = float(left["value"])
                    rval = float(right["value"])
                else:
                    lval = int(left["value"])
                    rval = int(right["value"])

                # evaluate
                if op == "SUM_OF":
                    result = lval + rval
                elif op == "DIFF_OF":
                    result = lval - rval
                elif op == "PRODUKT_OF":
                    result = lval * rval
                elif op == "QUOSHUNT_OF":
                    if rval == 0:
                        self.errors.append("Division by 0")
                        return {"type": "ERROR", "value": None}
                    
                    if finalType == "NUMBR":
                        result = int(lval/rval)
                    else:
                        result = lval/rval
                elif op == "MOD_OF":
                    if rval == 0:
                        self.errors.append("Modulo by 0")
                        return {"type": "ERROR", "value": None}
                    result = lval % rval


                # if result = NUMBR, result = int
                if finalType == "NUMBR" and not isinstance(result, int):
                    result = int(result)

                eval_stack.append({"type": finalType, "value": result})
                continue

            if current[0] == "MATH_OPERATION":
                op = current[1]

                # pop from stack
                right = eval_stack.pop()
                left = eval_stack.pop()

                if left["type"] == "ERROR" or right["type"] == "ERROR":
                    return {"type": "ERROR", "value": None}
                
                # orig types
                orig_left = left["type"]
                orig_right = right["type"]

                # type checking
                left = self.implicit_typecasting_numeric(left)
                right = self.implicit_typecasting_numeric(right)

                # if at least one operand is NUMBAR, result = NUMBAR
                if left["type"] == "NUMBAR" or right["type"] == "NUMBAR":
                    finalType = "NUMBAR"
                else:
                    # check if the original types
                    if orig_left == "NUMBAR" or orig_right == "NUMBAR":
                        finalType = "NUMBAR"
                    else:
                        finalType = "NUMBR"

                if finalType == "NUMBAR":
                    lval = float(left["value"])
                    rval = float(right["value"])
                else:
                    lval = int(left["value"])
                    rval = int(right["value"])

                # do operation
                if op == "SMALLR_OF":
                    result = min(lval,rval)
                if op == "BIGGR_OF":
                    result = max(lval,rval)

                if finalType == "NUMBR" and not isinstance(result, int):
                    result = int(result)

                eval_stack.append({"type": finalType, "value": result})
                continue

            if current[0] == "MULTI_BOOL_OPERATION":
                op = current[1]
                operand_cnt = current[2]

                operands = []
                
                for i in range(operand_cnt):
                    operand = eval_stack.pop() # get operand

                    #check for error
                    if operand["type"] == "ERROR":
                        return {"type": "ERROR", "value": None}
                    
                    # implicit type cast to troof
                    if operand["type"] != "TROOF":
                        if operand["value"] == 0 or operand["value"] == float(0) or operand["value"] == "":
                            opVal = False
                        else:
                            opVal = True
                    else:
                        opVal = operand["value"]
                    
                    # add to list
                    operands.append(opVal)
                
                if op == "ANY_OF":
                    result = any(operands)
                if op == "ALL_OF":
                    result = all(operands)

                eval_stack.append({"type": "TROOF", "value": result})
                continue


            if current[0] == "BOOL_OPERATION":
                op = current[1]
                result = None

                if op in ["BOTH_OF", "EITHER_OF", "WON_OF"]:
                    # pop from stack
                    right = eval_stack.pop()
                    left = eval_stack.pop()
                    
                    # check if operands are in symbol table
                    if left["type"] == "ERROR" or right["type"] == "ERROR":
                        return {"type": "ERROR", "value": None}

                    # implicit typecasting operands to TROOF(WIN/FAIL)
                    if left["type"] != "TROOF":
                        if left["value"] == 0 or left["value"] == float(0) or left["value"] == "":
                            lval = False
                        else:
                            lval = True
                    else:
                        lval = left["value"]
                        
                    if right["type"] != "TROOF":
                        if right["value"] == 0 or right["value"] == float(0) or right["value"] == "":
                            rval = False
                        else:
                            rval = True
                    else:
                        rval = right["value"]

                    # do the respective bool operations
                    if op == "BOTH_OF":
                        result = lval and rval
                    elif op == "EITHER_OF":
                        result = lval or rval
                    elif op == "WON_OF":
                        result = lval ^ rval
                                    
                elif op == "NOT":
                    operand = eval_stack.pop()
                    
                    # check if operands are in symbol table
                    if operand["type"] == "ERROR" :
                        return {"type": "ERROR", "value": None}

                    # implicit typecasting operand to TROOF(WIN/FAIL)
                    if operand["type"] != "TROOF":
                        if operand["value"] == 0 or operand["value"] == float(0) or operand["value"] == "":
                            opVal = False
                        else:
                            opVal = True
                    else:
                        opVal = operand["value"]
                    
                    result = not opVal
                
                eval_stack.append({"type": "TROOF", "value": result})
                continue


            if current[0] == "DO_SMOOSH":
                num_operands = current[1]
                operands = [eval_stack.pop() for _ in range(num_operands)]
                final_string = "" 
                
                for i, operand in enumerate(reversed(operands)):
                    val_type = operand.get("type")
                    val = operand.get("value")
                    if val_type == "NOOB":
                        printable_val = "NOOB"
                    elif val_type == "TROOF":
                        printable_val = "WIN" if val is True else "FAIL"
                    else:
                        printable_val = str(val) if val is not None else "" 
                    if printable_val:
                        final_string += printable_val

                    if i < num_operands - 1:
                        final_string += " "

                eval_stack.append({"type": "YARN", "value": final_string})
                continue
            
            if current[0] == "DO_COMPARE":
                op = current[1]

                right = eval_stack.pop()
                left = eval_stack.pop()

                if left["type"] == "ERROR" or right["type"] == "ERROR":
                    return {"type": "ERROR", "value": None}

                # BOTH_SAEM
                if op == "BOTH_SAEM":
                    
                    #typecast to numeric
                    left_cast = self.implicit_typecasting_numeric(left)
                    right_cast = self.implicit_typecasting_numeric(right)

                    #compare 
                    if left_cast["type"] != "ERROR" and right_cast["type"] != "ERROR":
                        is_equal = (float(left_cast["value"]) == float(right_cast["value"]))

                    else:
                        is_equal = self.is_equal(left, right)

                    eval_stack.append({"type": "TROOF", "value": is_equal})
                    continue

                # DIFFRINT
                if op == "DIFFRINT":

                    #typecast to numeric
                    left_cast = self.implicit_typecasting_numeric(left)
                    right_cast = self.implicit_typecasting_numeric(right)

                    #compare 
                    if left_cast["type"] != "ERROR" and right_cast["type"] != "ERROR":
                        is_not_equal = (float(left_cast["value"]) != float(right_cast["value"]))
                    else:
                        is_not_equal = not self.is_equal(left, right)
                    
                    eval_stack.append({"type": "TROOF", "value": is_not_equal})
                    continue


        # last value on eval_stack is the result
        return eval_stack[-1] if eval_stack else {"type": "UNKNOWN", "value": None}
    
    def analyze_statements(self, statements):
        """
        Analyzes a list of statements and updates the symbol table accordingly.
            (previously the analyze() function)
        """

        for stmt in statements:
            kind = stmt[0]

            if kind == "ASSIGN":
                var_name = stmt[1][1]
                expr = stmt[2]

                # if assignment is typecasting
                if isinstance(expr, tuple) and expr[0] == "IS NOW A":
                    target_type = expr[1]

                    if var_name not in self.symbol_table:
                        self.errors.append(f"Error: Cannot cast undefined variable '{var_name}'")
                        continue
                    
                    current_data = self.symbol_table[var_name]

                    # perform typecast
                    new_value = self.explicit_typecasting(current_data, target_type)

                    if new_value["type"] != "ERROR":
                        self.symbol_table[var_name] = new_value
                        self.symbol_table["IT"] = new_value.copy()
                    
                    continue 

                value_info = self.evaluate_expr_stack(expr)

                # update IT if expression was valid
                if value_info["type"] != "ERROR":
                    self.symbol_table["IT"]["type"] = value_info["type"]
                    self.symbol_table["IT"]["value"] = value_info["value"]

                # update assigned variable
                if var_name in self.symbol_table and value_info["type"] != "ERROR":
                    self.symbol_table[var_name]["type"] = value_info["type"]
                    self.symbol_table[var_name]["value"] = value_info["value"]

            elif kind == "DECLARATION":
                var_name = stmt[1][1]
                if len(stmt) > 2 and stmt[2] is not None:
                    expr = stmt[2]
                    value_info = self.evaluate_expr_stack(expr)

                    # update the symbol table with the evaluated result
                    if value_info["type"] != "ERROR":
                        # 1. Update the declared variable
                        self.symbol_table[var_name]["type"] = value_info["type"]
                        self.symbol_table[var_name]["value"] = value_info["value"]
                        
                        # update IT (last evaluated expression)
                        self.symbol_table["IT"]["type"] = value_info["type"]
                        self.symbol_table["IT"]["value"] = value_info["value"]
                    else:
                        self.errors.append(f"Error: Invalid expression for initialization of '{var_name}'.")
                        return self.errors, self.warnings
                    
            elif kind == "GIMMEH":
                var_name = stmt[1][1]

                # get input from user
                user_input = self.input_calls(var_name)

                self.symbol_table[var_name]["type"] = "YARN"
                self.symbol_table[var_name]["value"] = user_input
                self.symbol_table["IT"] = self.symbol_table[var_name].copy()


            elif kind == "VISIBLE":
                expressions = stmt[1]
                
                if not expressions:
                    self.symbol_table["IT"]["type"] = "YARN"
                    self.symbol_table["IT"]["value"] = ""
                    continue

                # dummy SMOOSH for the entire output string
                smoosh_expr = ("SMOOSH", *expressions)

                concatenated_result = self.evaluate_expr_stack(smoosh_expr)

                if concatenated_result["type"] == "ERROR":
                    self.errors.append("Error: cannot print invalid expression in VISIBLE.")
                    return self.errors, self.warnings, self.visible_output
                
                # store output
                val = concatenated_result["value"]
                val_type = concatenated_result["type"]

                if val_type == "NOOB":
                    output_string = "NOOB"
                else:
                    output_string = str(val)

                if self.print_to_console:
                    self.print_to_console(output_string + "\n")
                # store output
                self.visible_output.append(output_string)

                # IT concatenated string
                self.symbol_table["IT"]["type"] = "YARN"
                self.symbol_table["IT"]["value"] = concatenated_result["value"]

            #for evaluating expression before conditional statement (O RLY?)
            elif kind == "EXPRESSION_STMT":

                #get the expression
                if len(stmt) > 1:
                    expr = stmt[1]
                else:
                    expr = stmt
                
                value_info = self.evaluate_expr_stack(expr)
                
                #update IT if valid expression
                if value_info["type"] != "ERROR":
                    self.symbol_table["IT"]["type"] = value_info["type"]
                    self.symbol_table["IT"]["value"] = value_info["value"]
                else:
                    self.errors.append("Error: Invalid expression before conditional.")
                    return self.errors, self.warnings

            elif kind == "CONDITIONAL":
                self.analyze_conditional(stmt)

            elif kind == "IM IN YR":
                self.analyze_loop(stmt)

            elif kind == "FUNCTION_DEF":
                self.analyze_functiondef(stmt)
            
            elif kind == "FUNCTION_CALL":
                result = self.evaluate_expr_stack(stmt)
                
                if result["type"] != "ERROR":
                    self.symbol_table["IT"]["type"] = result["type"]
                    self.symbol_table["IT"]["value"] = result["value"]

            elif kind == "SWITCH CASE":
                self.analyze_switch_case(stmt)

                
        return self.errors, self.warnings
    

    def analyze(self):
        self.analyze_statements(self.ast)
        return self.errors, self.warnings, self.visible_output


def final_symTable(symbolTable):
    if not symbolTable:
        print("Symbol table empty.")
        return
    
    print("\n======== FINAL SYMBOL TABLE ========")
    print(f"\n{'Identifier':<20}{'Type':<10}{'Value':<20}")
    print("--------------------------------------------------") 
    
    if "IT" in symbolTable:
        data = symbolTable["IT"]
        print(f"{'IT':<20}{data['type']:<10}{str(data['value']):<20}")
        
    for name, data in symbolTable.items(): 
        if name == "IT":
            continue
        
        var_type = data['type']
        var_value = data['value']
        value_str = "NOOB" if var_value is None else str(var_value)

        print(f"{name:<20}{var_type:<10}{value_str:<20}")



def main():
    file_path = "./project-testcases/01_variables.lol" 
    
    tokens = tokenize(readFile(file_path))
    program = Parser(tokens)
    program_ast = program.parse()

    table = createSymTable(tokens)
    table["IT"] = {"type": "NOOB", "value": None}

    # if table:
    #     printSymTable(table)
    # else:
    #     print("No symbol table.")
    
    # print("\n======== SEMANTIC ANALYZER ========")
    analyzer = SemanticAnalyzer(program_ast, table)
    errors, warnings, visible_output = analyzer.analyze()

    #final_symTable(table)

    # for line in visible_output:
    #     print(line)

    # 2. warnings
    if warnings:
        print("\nSemantic Warnings:")
        for warning in warnings:
            print(f"- {warning}")

    # 3. errors
    if errors:
        print("\nSemantic Errors Found:")
        for error in errors:
            print(f"- {error}")

    # print("\n===PARSER===")
    # for t in tokens:
    #     print(t)

main()
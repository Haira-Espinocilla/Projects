
from finalproj import readFile, mainPattern, tokenize

literals = ["NUMBR", "NUMBAR", "YARN", "TROOF"]
data_types = ["NUMBR", "NUMBAR", "YARN", "TROOF", "NOOB"]
operations = ["SUM_OF", "DIFF_OF", "PRODUKT_OF", "QUOSHUNT_OF", "MOD_OF",   #arithmetic
              "BOTH_OF", "EITHER_OF", "WON_OF", "NOT",                      #boolean
              "BIGGR_OF", "SMALLR_OF",                                      #relational
              "BOTH_SAEM", "DIFFRINT",                                      #comparison
              "ANY_OF", "ALL_OF",                                           #multiple
              "SMOOSH"]                                                     #concatenation

class Parser():
    def __init__ (self,tokens):
        self.tokens = tokens
        self.token_index = 0
        self.variable_declarations = []

    # function for getting current token
    def curr_token(self):
        return self.tokens[self.token_index]
    
    def curr_token_type(self):
        return self.curr_token()[0]
    
    # function for moving to next token
    def move_to_next(self):
        if self.token_index < len(self.tokens):
            self.token_index +=1
    
    # function for matching expected keywords for operations, declaration, etc.
    def match(self, expected):
        token_type, token_val = self.curr_token()
        
        if token_type == expected:
            self.move_to_next() # increase token index to read next tokens
            return token_type,token_val
        else:
            raise Exception(f"Syntax Error: Expected '{expected}', but found '{token_type}")
        

    # function for skipping linebreaks
    def skip_linebreak(self):
        while self.curr_token_type() == "LINEBREAK":
            self.move_to_next()

    def parse_var_dec(self):
        declarations_ast = []
        
        self.skip_linebreak()
        while self.curr_token_type() != "BUHBYE":
            self.skip_linebreak()

            self.match("I_HAS_A")
            
            token_type, token_val = self.match("IDENTIFIER")
            var_name = token_val
            
            # default AST node for uninitialized vars
            expr = None 
            
            if self.curr_token_type() == "ITZ":
                self.move_to_next()

                expr_starters = literals + operations + ["IDENTIFIER", "MAEK", "SMOOSH", "NOT"]
                if self.curr_token_type() not in expr_starters:
                    raise Exception(f"Syntax Error: Expected expression after 'ITZ' for assignment to '{var_name}', "f"but found '{self.curr_token_type()}'.")

                expr = self.parse_expr() 
                # self.variable_declarations.append((var_name, expr))
            else:
                # self.variable_declarations.append((var_name,"NOOB"))
                pass

            declarations_ast.append(('DECLARATION', ('Variable', var_name), expr))

            self.skip_linebreak()

        self.match("BUHBYE") # read buhbye
        
        return declarations_ast
    
    def parse_typecasting(self):
        self.match("MAEK")
        if self.curr_token_type() == "IDENTIFIER":
            variable = self.parse_expr()
        else:
            raise Exception("Syntax Error: Expected a variable after MAEK.")
        
        token_type, token_val = self.curr_token()
        
        # check if typecasting to YARN 
        if token_val == "YARN":
            return("MAEK", variable, token_val)
        
        # if not, must have "A"
        self.match("A")
        
        token_type, token_val = self.curr_token()

        # check if token val is valid TYPE
        if token_val in data_types:
            self.move_to_next()
            typecast = token_val
        else:
            raise Exception(f"Syntax Error: Expected a TYPE, but found '{token_val}")

        return ("MAEK", variable ,typecast)
    

    def parse_printing(self):
        self.match("VISIBLE")

        #check if linebreak after VISIBLE
        if self.curr_token_type() == "LINEBREAK":
            self.move_to_next()
            return ("VISIBLE", [])

        exprs = []

        #check valid expression "starters"
        if self.curr_token_type() not in ["IDENTIFIER", "MAEK", "SMOOSH", "NOT"] + literals + operations:
            raise Exception("Syntax Error: Expected expression after 'VISIBLE'.")
        
        first_expr = self.parse_expr()
        exprs.append(first_expr)

        while self.curr_token_type() == "AN" or self.curr_token_type() in ["IDENTIFIER", "MAEK", "SMOOSH", "NOT"] + literals + operations:
            
            #check if AN
            if self.curr_token_type() == "AN":
                self.move_to_next()

            #check if valid expression "starters"
            if self.curr_token_type() in ["IDENTIFIER", "MAEK", "SMOOSH", "NOT"] + literals + operations:
                expr = self.parse_expr()

                if expr is None:
                    raise Exception("Syntax Error: Missing expression after 'AN' in VISIBLE statement.")
                    
                exprs.append(expr)

        return ("VISIBLE", exprs)
    
    def parse_input(self):
        self.match("GIMMEH")
        
        if self.curr_token_type() != "IDENTIFIER":
            raise Exception("Syntax Error: Expected variable name after 'GIMMEH'.")
        
        token_type, token_val = self.match("IDENTIFIER")
        
        return ("GIMMEH", ('variable', token_val))
    
    def parse_assignment(self):
        var_type, var_name = self.match("IDENTIFIER")

        token_type, token_val = self.curr_token()

        expr = None
        
        if token_val == "R":
            self.match("R")
                    # check if the next token can start an expression
            if self.curr_token_type() not in literals and self.curr_token_type() not in operations and self.curr_token_type not in data_types and self.curr_token_type()!= "MAEK" and self.curr_token_type() != "IDENTIFIER":
                raise Exception(f"Syntax Error: Expected expression after 'R' for assignment to '{var_name}', "f"but found '{self.curr_token_type()}'.")

            # parse the expression
            expr = self.parse_expr()

        elif token_val == "IS NOW A":
            self.match("IS_NOW_A")
            token_type, token_val = self.curr_token()

            # check if token val is valid TYPE
            if token_val in data_types:
                self.move_to_next()
                typecast = token_val
            else:
                raise Exception(f"Syntax Error: Expected a TYPE, but found '{token_val}")
            
            expr = ("IS NOW A",typecast)


        return ("ASSIGN", ('variable', var_name), expr)
    
    def parse_unary_operation(self, operation):
        self.move_to_next()

        if self.curr_token_type() not in literals and self.curr_token_type() not in operations and self.curr_token_type() != "IDENTIFIER":
            raise Exception(f"Syntax Error: Expected operand after '{operation}', "f"but found '{self.curr_token_type()}'.")
        
        operand = self.parse_expr()
        return (operation, operand)

    def parse_comparison_operations(self, operation):
        self.move_to_next()
        operand1 = self.parse_expr()
        self.match("AN")
        operand2 = self.parse_expr()

        return (operation, operand1, operand2)
    
    def parse_multiple_operations(self, operation):
        self.move_to_next()
        exprs = []        # list for expressions
        exprs.append(self.parse_expr())

        while self.curr_token_type() == "AN":
            self.move_to_next()
            exprs.append(self.parse_expr())
        self.match("MKAY")  # read MKAY

        return(operation, *exprs)

    def parse_operations(self, operation):
        self.move_to_next()

        def expr_start(token_type):
            return token_type in literals or token_type in operations or token_type == "IDENTIFIER"

        if not expr_start(self.curr_token_type()):
            raise Exception(f"Syntax Error: Expected first operand after '{operation}', "f"but found '{self.curr_token_type()}'.")

        operand1 = self.parse_expr()

        # must have AN
        if self.curr_token_type() != "AN":
            raise Exception(f"Syntax Error: Missing 'AN' after first operand of '{operation}'.")
        self.move_to_next()

        if not expr_start(self.curr_token_type()):
            raise Exception(f"Syntax Error: Expected second operand after 'AN', "f"but found '{self.curr_token_type()}'.")

        operand2 = self.parse_expr()

        return (operation, operand1, operand2)
    

    def parse_smoosh(self):
        self.move_to_next()
        exprs = []

        exprs.append(self.parse_expr())

        while self.curr_token_type() == "AN":
            self.move_to_next()      # skip AN
            exprs.append(self.parse_expr())
        
        return ("SMOOSH", *exprs)
    
    def parse_statement(self):
        tok = self.curr_token_type()

        if tok == "VISIBLE":
            return self.parse_printing()

        if tok == "GIMMEH":
            return self.parse_input()

        if tok == "IDENTIFIER":
            return self.parse_assignment()

        if tok == "MAEK":
            return self.parse_typecasting()

        if tok == "SMOOSH":
            return self.parse_smoosh()

        if tok == "IM_IN_YR":
            return self.parse_loop()
        
        if tok == "O_RLY":
            return self.parse_conditional()

        raise Exception(f"Syntax Error: Unexpected statement token '{tok}'. ")
        
    def parse_functiondef(self):
        self.move_to_next()

        if self.curr_token_type() != "IDENTIFIER":
            raise Exception(f"Syntax Error: Expected identifier after 'HOW IZ I' for function call, but found '{self.curr_token_type()}'.")
        
        token_type, token_val = self.match("IDENTIFIER")
        func_name = token_val

        arguments = []
        func_statements = []
        return_val = []

        # getting parameters
        while self.curr_token_type() == "YR":            
            self.match("YR") # must have YR

            if self.curr_token_type() != "IDENTIFIER":
                raise Exception(f"Syntax Error: Expected identifier after 'HOW IZ I' for function call, but found '{self.curr_token_type()}'.")
            
            token_type, token_val = self.match("IDENTIFIER")
            arguments.append(token_val)

            if self.curr_token_type() == "AN":
                self.move_to_next() # skip AN

            self.skip_linebreak()

        while self.curr_token_type() != "IF_U_SAY_SO":
            self.skip_linebreak()

            if self.curr_token_type() == "IF_U_SAY_SO":
                break

            self.skip_linebreak()

            # for returning statements, break when return statement has already been found
            if self.curr_token_type() == "FOUND_YR":
                self.move_to_next()
                expr = self.parse_expr()
                return_val = expr
                break

            elif self.curr_token_type() == "GTFO":
                self.move_to_next()
                return_val = ("NOOB")
                break

            # get statements
            stmt = self.parse_statement()
            if stmt is not None:
                func_statements.append(stmt)
            self.skip_linebreak()
            
        self.skip_linebreak()
        self.match("IF_U_SAY_SO")

        # if no GTFO is found, the return type will be NOOB automatically
        if not return_val:
            return_val = ("NOOB")
        
        return ("FUNCTION_DEF",(func_name, arguments, func_statements, return_val))

    
    def parse_functioncall(self):
        self.match("I_IZ")

        if self.curr_token_type() != "IDENTIFIER":
            raise Exception(f"Syntax Error: Expected identifier after 'I IZ' for function call, but found '{self.curr_token_type()}'.")
        
        token_type, token_val = self.match("IDENTIFIER")
        func_name = token_val
        
        arguments = []
        while self.curr_token_type() != "MKAY":   
            self.match("YR") # must have YR

            arg_expr = self.parse_expr()
            arguments.append(arg_expr)

            if self.curr_token_type() == "AN":
                self.move_to_next() # skip AN to move to next argument
            
        self.match("MKAY")

        return("FUNCTION_CALL",(func_name, arguments))

    def parse_loop(self):
        self.match("IM_IN_YR")

        loop_tok, loop_name = self.match("IDENTIFIER")

        loop_updown = None 
        loop_var = None
        condition_type = None
        condition_expr = None

        # optional loop counter
        if self.curr_token_type() in ["UPPIN_YR", "NERFIN_YR"]:
            loop_updown = self.curr_token_type()
            self.move_to_next()

            # consume loop variable
            loop_type, loop_var = self.match("IDENTIFIER")

        # loop termination condition
        if self.curr_token_type() in ["TIL", "WILE"]:
            condition_type = self.curr_token_type()
            self.move_to_next()
            condition_expr = self.parse_expr()

        loop_stmtbody = [] # store statements within loop
        self.skip_linebreak()

        # loop until exit
        while self.curr_token_type() != "IM_OUTTA_YR":
            stmt = self.parse_statement()
            if stmt is not None:
                loop_stmtbody.append(stmt)
            self.skip_linebreak()

        self.match("IM_OUTTA_YR")
        exit_tok, exit_name = self.match("IDENTIFIER")

        # if closing loop name matches starting loop name
        if exit_name != loop_name:
            raise Exception(f"Syntax Error: LOOP name mismatch: started '{loop_name}' but closed '{exit_name}'")

        return ("IM IN YR", loop_name, loop_updown, loop_var, condition_type, condition_expr, loop_stmtbody)

    def parse_conditional(self):
        self.match("O_RLY")
        self.skip_linebreak()
        self.match("YA_RLY")
        self.skip_linebreak()
        
        #YA RLY: get statements under ya rly
        yarly_stmt = []
        while self.curr_token_type() not in ["MEBBE", "NO_WAI", "OIC"]:
            stmt = self.parse_statement()
            if stmt is not None:
                yarly_stmt.append(stmt)
            self.skip_linebreak()

            #check if ya rly has at least one statement
            if not yarly_stmt and self.curr_token_type() in ["MEBBE", "NO_WAI", "OIC"]:
                raise Exception(f"Syntax Error: YA RLY block must have at least one statement.")
            
        conditional = ("O RLY?", ("YA RLY", yarly_stmt))
        

        # #MEBBE: optional
        # mebbe_blocks = []
        # while self.curr_token_type() == "MEBBE":
        #     self.match("MEBBE")
        #     self.skip_linebreak()

        #     #get statements under mebbe
        #     mebbe_stmt = []
        #     while self.curr_token_type() not in ["MEBBE", "NO WAI", "OIC"]:
        #         stmt = self.parse_statement()
        #         if stmt is not None:
        #             mebbe_stmt.append(stmt)
        #         self.skip_linebreak()

        #         #check if mebbe has at least one statement
        #         if not mebbe_stmt and self.curr_token_type() in ["NO WAI", "OIC"]:
        #             raise Exception(f"Syntax Error: MEBBE block must have at least one statement.")

        #     mebbe_blocks.append(("MEBBE", mebbe_stmt))

        # #add mebbe blocks
        # if mebbe_blocks:
        #     conditional = (*conditional, ("MEBBE", mebbe_blocks))


        #NO WAI: optional
        if self.curr_token_type() == "NO_WAI":
            self.match("NO_WAI")
            self.skip_linebreak()

            #get statements under no wai
            no_wai_stmt = []
            while self.curr_token_type() != "OIC":
                stmt = self.parse_statement()
                if stmt is not None:
                    no_wai_stmt.append(stmt)
                self.skip_linebreak()

                #check if no wai has at least one statement
                if not no_wai_stmt and self.curr_token_type() == "OIC":
                    raise Exception(f"Syntax Error: NO WAI block must have at least one statement.")

            conditional = (*conditional, ("NO WAI", no_wai_stmt))

        self.match("OIC")
        return ("CONDITIONAL", conditional)
    
    def parse_switch_case(self):
        self.match("WTF")
        self.skip_linebreak()

        code_blocks = []
        omgwtf_block = None
        with_gtfo = False

        while self.curr_token_type() == "OMG":
            self.match("OMG")

            if self.curr_token_type() not in literals:
                raise Exception(f"Syntax Error: Expected literal after 'OMG'.")
            
            case_val_type, case_val = self.curr_token()
            self.move_to_next()
            
            self.skip_linebreak()

            case_stmt_body = []
            while self.curr_token_type() not in ["OMG", "OMGWTF", "OIC", "GTFO"]:   
                stmt = self.parse_statement()
                if stmt is not None:
                    case_stmt_body.append(stmt)
                self.skip_linebreak()

                if not case_stmt_body and self.curr_token_type() in ["OMG", "OMGWTF", "OIC"]:
                    raise Exception(f"Syntax Error: OMG block must have at least one statement.")

            #check if end of code block has GTFO
            if self.curr_token_type() == "GTFO":
                self.match("GTFO")
                with_gtfo = True
                self.skip_linebreak()

            code_blocks.append((case_val_type, case_val, case_stmt_body, with_gtfo))
            with_gtfo = False

        #OMGWTF: optional
        if self.curr_token_type() == "OMGWTF":
            self.match("OMGWTF")
            self.skip_linebreak()

            stmt_body = []
            while self.curr_token_type() != "OIC":
                stmt = self.parse_statement()
                if stmt is not None:
                    stmt_body.append(stmt)
                self.skip_linebreak()

                if not stmt_body and self.curr_token_type() == "OIC":
                    raise Exception(f"Syntax Error: OMGWTF block must have at least one statement.")

            omgwtf_block = ("OMGWTF", stmt_body)

        self.match("OIC")
        return ("SWITCH CASE", code_blocks, omgwtf_block)

    def parse_expr(self):
        token_type, token_val = self.curr_token()

        # case 1: literal (NUMBR, NUMBAR, etc.)
        if token_type in literals:
            self.move_to_next()
            return (token_type, token_val)

        # case 2: identifier
        elif token_type == "IDENTIFIER":
            self.move_to_next()
            return ('Variable', token_val)
        
        # case 3: NOT
        elif token_type == "NOT":
            return self.parse_unary_operation(token_type)
        
        # case 4: arithmetic, relational, & boolean operations
        elif token_type in ["SUM_OF", "DIFF_OF", "PRODUKT_OF", "QUOSHUNT_OF", "MOD_OF", "BOTH_OF", "EITHER_OF", "WON_OF", "BIGGR_OF", "SMALLR_OF"]:
            return self.parse_operations(token_type)
        
        # case 5: comparison operations
        elif token_type in ["BOTH_SAEM", "DIFFRINT"]:
            return self.parse_comparison_operations(token_type)
        
        # case 6: multiple operations
        elif token_type in ["ANY_OF", "ALL_OF"]:
            return self.parse_multiple_operations(token_type)
        
        elif token_type =="MAEK":
            return self.parse_typecasting()
        #case 7: smoosh
        elif token_type == "SMOOSH":
            return self.parse_smoosh()

        # case 8: invalid start of expression
        else:
            raise Exception(f"Syntax Error: Unexpected expression start '{token_type}'.")
        

    def parse(self):
        if self.curr_token_type() == "HAI":
            print("\n\n====== SYNTAX ANALYZER ======")
            print("Start of Program:")
            self.move_to_next() 
            self.skip_linebreak()

            program_ast = [] # master list for semantic analyzer
            print_statements = []
            input_statements = []
            assignment_statements = []
            typecasting_statements = []
            functions =[]
            function_calls = []
            loop_statements = []
            conditional_statements = []
            switch_cases = []

            # loop until KTHXBYE
            while self.curr_token_type() != "KTHXBYE":
                self.skip_linebreak()

                if self.curr_token_type() == "KTHXBYE":
                    break

                if self.curr_token_type() == "WAZZUP":
                    self.move_to_next() # move past WAZZUP

                    #self.parse_var_dec()
                    declaration_nodes = self.parse_var_dec()
                    program_ast.extend(declaration_nodes)
                    

                    # print("\n=========== AST ===========")
                    # for i in self.variable_declarations:
                    #     if isinstance(i, tuple):
                    #         name, expr = i
                    #         print(f"Variable '{name}':")
                    #         print_ast_tree(expr)    

                    #     else:
                    #         print(f"Variable '{i}' has no value")
                
                elif self.curr_token_type() == "HOW_IZ_I":
                    function_def = self.parse_functiondef()
                    functions.append((function_def))
                    program_ast.append(function_def)
                
                elif self.curr_token_type() == "VISIBLE":
                    printStmt = self.parse_printing()
                    print_statements.append(printStmt)
                    program_ast.append(printStmt) # add to master list

                elif self.curr_token_type() == "GIMMEH":
                    inputStmt = self.parse_input()
                    input_statements.append(inputStmt)
                    program_ast.append(inputStmt) 

                elif self.curr_token_type() == "IDENTIFIER":
                    assign = self.parse_assignment()
                    assignment_statements.append(assign)
                    program_ast.append(assign)
                
                elif self.curr_token_type() == "MAEK":
                    typecasting = self.parse_typecasting()
                    typecasting_statements.append(typecasting)
                    program_ast.append(typecasting)
                
                elif self.curr_token_type() == "SMOOSH":
                    smoosh_expr = self.parse_smoosh()
                    program_ast.append(smoosh_expr)

                elif self.curr_token_type() == "I_IZ":
                    function_call = self.parse_functioncall()
                    function_calls.append(function_call)
                    program_ast.append(function_call)

                elif self.curr_token_type() == "IM_IN_YR":
                    loop = self.parse_loop()
                    loop_statements.append(loop)
                    program_ast.append(loop)

                elif self.curr_token_type() == "O_RLY":
                    conditional = self.parse_conditional()
                    conditional_statements.append(conditional)
                    program_ast.append(conditional)

                elif self.curr_token_type() == "WTF":
                    switch_case = self.parse_switch_case()
                    switch_cases.append(switch_case)
                    program_ast.append(switch_case)

                elif self.curr_token_type() in operations + literals + ["MAEK", "SMOOSH"]: 
                    expr = self.parse_expr()
                    program_ast.append(("EXPRESSION_STMT", expr))
                    
                else:
                    raise Exception(f"Syntax Error: Unexpected token '{self.curr_token_type()}'. Expected a statement or 'KTHXBYE'.")

            
            if print_statements:
                print("\nPrint Statements:")
                
                # flatten all expressions from all print statements
                allExprs = [expr for stmt in print_statements for expr in stmt[1]]
                
                print_ast_tree(("VISIBLE", *allExprs))

            if assignment_statements:
                print("\nAssignment Statements:")
                for stmt in assignment_statements:
                    print_ast_tree(stmt)
            
            if typecasting_statements:
                print("\nTypecasting Statements:")
                for stmt in typecasting_statements:
                    print_ast_tree(stmt)
                    
            if input_statements:
                print("\nInput Statements:")
                for stmt in input_statements:
                    print_ast_tree(stmt)

            if functions:
                print("\nFunction Definitions:")
                for function in functions:
                    print_ast_tree(function)
                    
            if function_calls:
                print("\nFunction Calls:")
                for func_call in function_calls:
                    print_ast_tree(func_call)

            if loop_statements:
                print("\nLoop Statements:")
                for stmt in loop_statements:
                    print_ast_tree(stmt)

            if conditional_statements:
                print("\nConditional Statements:")
                for stmt in conditional_statements:
                    print_ast_tree(stmt)

            if switch_cases:
                print("\nSwitch Cases:")
                for case in switch_cases:
                    print_ast_tree(case)

            self.match("KTHXBYE") # Move past KTHXBYE
            print("End of Program")
            
            # return master list for semantic analyzer
            return program_ast
        
        else:
            raise Exception("Syntax Error: Cannot find starting delimeter. Program should start with HAI")

def print_ast_tree(node, prefix= " ", last=True):

    if isinstance(node, tuple):
        node_name = node[0]
        children = node[1:]
    elif isinstance(node, list):
        node_name = None
        children = node
    else:
        node_name = str(node)
        children = []

    if node_name is not None:
        #branches
        if last:
            branch = "└──"
        else:
            branch = "├──"

        #print node
        print(f"{prefix}{branch} {node_name}")
    
    #update prefix for children
    new_prefix = prefix
    if not last:
        new_prefix += "│  "     #continue
    else:   
        new_prefix += "   "     #end

    # #call recursively for each child
    
    flatten_children = []
    for child in children:
        if isinstance(child, list):
            flatten_children.extend(child)
        else:
            flatten_children.append(child)

    children_count = len(flatten_children)
    for i, child in enumerate(flatten_children):
        is_last = (i == children_count - 1)
        print_ast_tree(child, new_prefix, is_last)


# ============ Symbol Table Functions ============
def addToTable(symbolTable, name, value):
    # add or update an entry
    symbolTable[name] = value

def printSymTable(symbolTable):
    if not symbolTable:
        print("Symbol table empty.")
        return
    
    print("\n======== INITIAL SYMBOL TABLE ========")
    print(f"\n{'Identifier':<20}{'Type':<10}{'Value':<20}")
    print("--------------------------------------------------") 
    
    for name, data in symbolTable.items(): 
        if isinstance(data, dict):
            var_type = data['type']
            var_value = data['value']
            value_str = str(var_value)
        else:
            var_type = "UNKNOWN"
            value_str = str(data)
        print(f"{name:<20}{var_type:<10}{value_str:<20}")


def createSymTable(tokens):
    symbolTable = {}
    literals_list = literals
    
    # initialize IT
    symbolTable['IT'] = {'type': 'NOOB', 'value': None}

    i = 0
    tokCount = len(tokens)
    
    while i < tokCount: 
        tokType = tokens[i][0]

        if tokType == "I_HAS_A":
            if i + 1 < tokCount and tokens[i+1][0] == "IDENTIFIER":
                identName = tokens[i+1][1]
                
                var_data = {'type': 'NOOB', 'value': None}

                if i + 2 < tokCount and tokens[i+2][0] == "ITZ":
                    # check if the token after ITZ is a literal 
                    if i + 3 < tokCount:
                        typeVal = tokens[i+3][0]
                        litVal = tokens[i+3][1]

                        if typeVal in literals_list:
                            var_data['type'] = typeVal
                            litVal = litVal.strip('"') 
                            
                            # type coercion for initial symbol table
                            if typeVal == 'NUMBR':
                                var_data['value'] = int(litVal)
                            elif typeVal == 'NUMBAR':
                                var_data['value'] = float(litVal)
                            elif typeVal == 'TROOF':
                                var_data['value'] = True if litVal == "WIN" else False
                            elif typeVal == 'YARN':
                                var_data['value'] = litVal

                symbolTable[identName] = var_data
        
        i += 1 
        
    return symbolTable
        
def main():
    filePath = "sample.lol"
    tokens = tokenize(readFile(filePath))

    table = createSymTable(tokens)
    if table:
        printSymTable(table)
    else:
        print("No symbol table.")

    tokens = tokenize(readFile(filePath))
    program = Parser(tokens)
    program.parse()

if __name__ == "__main__": 
    main()

import tkinter as tk
from tkinter import filedialog, ttk
from tkinter.scrolledtext import ScrolledText
import ttkbootstrap as ttk
from ttkbootstrap.constants import *
import sys 

from finalproj import tokenize, classify 
from finalproj_syntax import Parser, createSymTable 
from finalproj_semantic import SemanticAnalyzer 


#### HELPER FUNCTIONS #####

waiting_for_input = False
input_value = None

def console_input_calls(varname):
    global waiting_for_input, input_value, input_start_index

    # enale console
    console_text.config(state='normal') 
    
    # where user input starts
    input_start_index = console_text.index("end-1c") 

    waiting_for_input = True
    input_value = None

    # wait for input
    while input_value is None:
        root.update()

    return input_value


def press_enter(event):
    global waiting_for_input, input_value, input_start_index

    if waiting_for_input:
        # extract input from start index up to current cursor
        value = console_text.get(input_start_index, "end-1c").strip()

        input_value = value
        waiting_for_input = False

        console_text.insert("end-1c", "\n")
        console_text.config(state='disabled') 

    return "break"

def print_to_console(text):
    if waiting_for_input:
        return  # prevent any output during GIMMEH

    console_text.config(state='normal')
    console_text.insert(tk.END, text)
    console_text.see(tk.END)
    console_text.config(state='disabled') # Console should be disabled after normal output


#function: clears the console when call
def clear_all():    
    for item in tokens_tree.get_children():     #get children in tokens
        tokens_tree.delete(item)
    
    for item in symbol_tree.get_children():     #get children in symbol tree
        symbol_tree.delete(item)

    console_text.config(state='normal')     
    console_text.delete('1.0', tk.END)

def clear_console():
    console_text.config(state='normal')     
    console_text.delete('1.0', tk.END)

#function: updates the tokens
def update_tokens(tokens):
    for tokType, tokVal in tokens:
        classification = classify(tokType, tokVal)

        if tokType == "YARN":
            tokens_tree.insert('', tk.END, values=('"', "String Delimiter"))
            tokens_tree.insert('', tk.END, values=(tokVal.strip('"'), "Literal"))
            tokens_tree.insert('', tk.END, values=('"', "String Delimiter"))

        else:
            tokens_tree.insert('', tk.END, values=(tokVal, classification))

#updates the symbol table
def update_symbol_table(symbol_table):
    for item in symbol_tree.get_children():
        symbol_tree.delete(item)

    #it
    if 'IT' in symbol_table:
        data = symbol_table['IT']
        val = data['value'] if data['value'] is not None else "NOOB"
        symbol_tree.insert('', tk.END, values=('IT', data['type'], val))

    for name, data in symbol_table.items():
        if name != 'IT':
            val = data['value']
            if val is None:
                val = "NOOB"
            symbol_tree.insert('', tk.END, values=(name, data['type'], val))


#function: prints the final symbol table (from the semantic analyzer file)
def print_final_symbol_table(symbol_table):
    if not symbol_table:
        print("Symbol table empty.")
        return
    
    print("\n======== FINAL SYMBOL TABLE ========")
    print(f"\n{'Identifier':<20}{'Type':<10}{'Value':<20}")
    print("--------------------------------------------------") 
    
    if "IT" in symbol_table:
        data = symbol_table["IT"]
        print(f"{'IT':<20}{data['type']:<10}{str(data['value']):<20}")
        
    for name, data in symbol_table.items(): 
        if name == "IT":
            continue
        
        var_type = data['type']
        var_value = data['value']
        value_str = str(var_value)

        print(f"{name:<20}{var_type:<10}{value_str:<20}")


##### File Explorer and Execution Functions #####
def load_file():
    filepath = filedialog.askopenfilename(
        filetypes=[("Text Files", "*.txt"), ("All Files", "*.*"), ("LOLcode Files", "*.lol")],
    )
    if filepath:
        try:
            with open(filepath, 'r') as file:
                content = file.read()
                text_editor.delete('1.0', tk.END)
                text_editor.insert(tk.END, content)
            root.title(f"CMSC 124 Project - {filepath.split('/')[-1]}")
        except Exception as e:
            console_text.insert(tk.END, f"\nError loading file: {e}\n")
            console_text.see(tk.END)

#class: puts text to console
class put_to_console:
    def __init__(self, widget):
        self.widget = widget

    def write(self, text):
        self.widget.config(state='normal')
        self.widget.insert(tk.END, text)
        self.widget.see(tk.END)
        self.widget.config(state='disabled')

    def flush(self):
        pass

#function: executes the code
def execute():
    clear_all()

    code = text_editor.get('1.0', tk.END)
    if not code.strip():
        console_text.config(state='normal')
        console_text.insert(tk.END, "Error: No code to execute.\n")
        console_text.config(state='disabled')
        return

    try:
        # tokenize and show tokens
        tokens = tokenize(code)
        update_tokens(tokens)

        # initialize symbol table
        table = createSymTable(tokens)
        table["IT"] = {"type": "NOOB", "value": None}
        update_symbol_table(table)   # show initial 

        # parse AST
        tokens2 = tokenize(code) 
        program = Parser(tokens2)
        program_ast = program.parse()

        # semantic analysis
        analyzer = SemanticAnalyzer(program_ast, table, input_calls=console_input_calls, print_to_console=print_to_console)
        errors, warnings, _ = analyzer.analyze()

        # update symbol table after execution
        update_symbol_table(table)
        
    except Exception as e:
        console_text.config(state='normal')
        
        # print errors and warnings
        if warnings:
            console_text.insert(tk.END, "\nSemantic Warnings:\n")
            for w in warnings:
                console_text.insert(tk.END, f"- {w}\n")
        if errors:
            console_text.insert(tk.END, "\nSemantic Errors Found:\n")
            for e in errors:
                console_text.insert(tk.END, f"- {e}\n")
        
        
        console_text.insert(tk.END, f"\nExecution Failed: {type(e).__name__}: {e}\n")
        console_text.see(tk.END)
        console_text.config(state='disabled')
        
        return

##### GUI Proper #####
#window setup
root = ttk.Window(themename="flatly")
root.title("CMSC 124 Project: LOLcode Interpreter")
root.geometry("1600x1000")

#layout configurations
root.grid_columnconfigure(0, weight=1) 
root.grid_columnconfigure(1, weight=1) 
root.grid_rowconfigure(0, weight=1)    

###### LEFT PANEL - TEXT EDITOR, FILE EXPLORER ######
left_panel = ttk.Frame(
    root, 
    padding = 10,
    relief=tk.FLAT
)
ttk.Style().configure('TFrame', background="#f0f0f0")

left_panel.grid(row=0, column=0, sticky="nsew", padx=5, pady=5)
left_panel.grid_rowconfigure(1, weight=1)       
left_panel.grid_columnconfigure(0, weight=0)    
left_panel.grid_columnconfigure(1, weight=1)    

#Text Editor Label
text_editor_label = ttk.Label(
    left_panel,
    text = "Text Editor",
    font=("Helvetica", 11, "bold"),
    bootstyle="primary",
    background="#f0f0f0"
)
text_editor_label.grid(row=0, column=0, sticky="w", pady=(0, 5), padx=10)

#File Explorer Button
file_exp_button = ttk.Button(
    left_panel,
    text = "File Explorer",
    command = load_file,
    bootstyle=INFO
)
file_exp_button.grid(row=0, column=1, sticky="e", pady=(0, 5), padx=5)

#Text Editor
text_editor = ScrolledText(
    left_panel, 
    wrap=tk.WORD, 
    font=("Consolas", 13),
    relief=tk.FLAT,
)
text_editor.insert("1.0", "This is a sample text editor")
text_editor.grid(row=1, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)

###### RIGHT PANEL: TOKENS, SYMBOL TREE, CONSOLE, EXECUTE ######
right_panel = ttk.Frame(
    root,
    padding = 10,
    relief=tk.FLAT
)
ttk.Style().configure('TFrame', background="#f0f0f0")

right_panel.grid(row=0, column=1, sticky="nsew", padx=5, pady=5)
right_panel.grid_columnconfigure(0, weight=1)
right_panel.grid_columnconfigure(1, weight=1)
right_panel.grid_rowconfigure(1, weight=2)      #token/symbol
right_panel.grid_rowconfigure(3, weight=1)      #console

#Tokens Label
tokens_label = ttk.Label(
    right_panel,
    text = "Tokens",
    font=("Helvetica", 11, "bold"),
    background="#f0f0f0",
)
tokens_label.grid(row=0, column=0, sticky="n", pady=(0, 5), padx=10)

#Tokens view
tokens_tree = ttk.Treeview(
    right_panel,
    columns=("Lexeme", "Classification"),
    show='headings',
)
tokens_tree.heading("Lexeme", text="Lexeme", anchor=tk.W)
tokens_tree.heading("Classification", text="Classification", anchor=tk.W)
tokens_tree.column("Lexeme", anchor=tk.W, width=150)
tokens_tree.column("Classification", anchor=tk.W, width=150)
tokens_tree.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)

#Symbol Table Label
symbol_table_label = ttk.Label(
    right_panel,
    text = "Symbol Table",
    font=("Helvetica", 11, "bold"),
    background="#f0f0f0"
)
symbol_table_label.grid(row=0, column=1, sticky="n", pady=(0, 5), padx=10)

symbol_tree = ttk.Treeview(
    right_panel,
    columns=("Identifier", "Type", "Value"),
    show='headings'
)
symbol_tree.heading("Identifier", text="Identifier", anchor = tk.W)
symbol_tree.heading("Type", text="Type", anchor = tk.W)
symbol_tree.heading("Value", text="Value", anchor = tk.W)
symbol_tree.column("Identifier", anchor=tk.W, width=100)
symbol_tree.column("Type", anchor=tk.W, width=100)
symbol_tree.column("Value", anchor=tk.W, width=150)
symbol_tree.grid(row=1, column=1, sticky="nsew", padx=5, pady=5)


#Console Label
console_label = ttk.Label(
    right_panel,
    text = "Console Output",
    font=("Helvetica", 11, "bold"),
    background="#f0f0f0"
)
console_label.grid(row=2, column=0, sticky="w", pady=(0, 5), padx=10)

#Frame for execute and clear buttons
button_frame = ttk.Frame(right_panel)
button_frame.grid(row=2, column=1, sticky="e", pady=(0, 5), padx=5)

#Execute Button
execute_button = ttk.Button(
    button_frame,
    text = "Execute",
    command = execute,
    bootstyle=SUCCESS
)
execute_button.pack(side="left", padx=(0, 5))

#Clear Button
clear_button = ttk.Button(
    button_frame,
    text = "Clear",
    command = clear_console,
    bootstyle=WARNING
)
clear_button.pack(side="left", padx=(0, 5))

#Console Text Box
console_text = ScrolledText(
    right_panel, 
    wrap=tk.WORD, 
    font=("Consolas", 13),
    relief=tk.FLAT,
    height=10, 
    state='normal' 
)
console_text.grid(row=3, column=0, columnspan=2, sticky="nsew", padx=5, pady=5)
console_text.config(state='normal')

console_text.bind("<Return>", press_enter)

root.mainloop()

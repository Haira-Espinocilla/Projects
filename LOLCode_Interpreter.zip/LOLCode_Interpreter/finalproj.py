import re

# keywords and token patterns for LOLCODE
keywordSpecs = [
    # comments
    ("COMMENT", r"\bBTW\b[^\n]*\n"),
    ("OBTW", r"\bOBTW\b"),
    ("TLDR", r"\bTLDR\b"),
    
    # literals 
    ("NUMBAR", r"-?[0-9]+\.[0-9]+"),
    ("NUMBR", r"-?[0-9]+"),
    ("YARN", r'"[^"]*"'),
    ("TROOF", r"\b(WIN|FAIL)\b"),
    ("TYPE", r"\b(NUMBR|NUMBAR|YARN|TROOF)\b"),

    # keywords na may spaces
    ("I_HAS_A", r"\bI HAS A\b"),
    ("SUM_OF", r"\bSUM OF\b"),
    ("DIFF_OF", r"\bDIFF OF\b"),
    ("PRODUKT_OF", r"\bPRODUKT OF\b"),
    ("QUOSHUNT_OF", r"\bQUOSHUNT OF\b"),
    ("MOD_OF", r"\bMOD OF\b"),
    ("BIGGR_OF", r"\bBIGGR OF\b"),
    ("SMALLR_OF", r"\bSMALLR OF\b"),
    ("BOTH_OF", r"\bBOTH OF\b"),
    ("EITHER_OF", r"\bEITHER OF\b"),
    ("WON_OF", r"\bWON OF\b"),
    ("ANY_OF", r"\bANY OF\b"),
    ("ALL_OF", r"\bALL OF\b"),
    ("BOTH_SAEM", r"\bBOTH SAEM\b"),
    ("IS_NOW_A", r"\bIS NOW A\b"),
    ("O_RLY", r"\bO RLY\?"),
    ("YA_RLY", r"\bYA RLY\b"),
    ("NO_WAI", r"\bNO WAI\b"),
    ("IM_IN_YR", r"\bIM IN YR\b"),
    ("IM_OUTTA_YR", r"\bIM OUTTA YR\b"),
    ("HOW_IZ_I", r"\bHOW IZ I\b"),
    ("IF_U_SAY_SO", r"\bIF U SAY SO\b"),
    ("FOUND_YR", r"\bFOUND YR\b"),
    ("I_IZ", r"\bI IZ\b"),
    ("UPPIN_YR", r"\bUPPIN YR\b"),
    ("NERFIN_YR", r"\bNERFIN YR\b"),

    # keywords na walang spaces
    ("HAI", r"\bHAI( *([0-9]+\.[0-9]+)?)\b"),
    ("KTHXBYE", r"\bKTHXBYE\b"),
    ("VISIBLE", r"\bVISIBLE\b"),
    ("GIMMEH", r"\bGIMMEH\b"),
    ("ITZ", r"\bITZ\b"),
    ("R", r"\bR\b"),
    ("AN", r"\bAN\b"),
    ("DIFFRINT", r"\bDIFFRINT\b"),
    ("SMOOSH", r"\bSMOOSH\b"),
    ("MAEK", r"\bMAEK\b"),
    ("A", r"\bA\b"),
    ("MEBBE", r"\bMEBBE\b"),
    ("OIC", r"\bOIC\b"),
    ("WTF", r"\bWTF\?"),
    ("OMG", r"\bOMG\b"),
    ("OMGWTF", r"\bOMGWTF\b"),
    ("YR", r"\bYR\b"),
    ("TIL", r"\bTIL\b"),
    ("WILE", r"\bWILE\b"),
    ("GTFO", r"\bGTFO\b"),
    ("MKAY", r"\bMKAY\b"),
    ("LINEBREAK", r"\n"),
    ("WAZZUP", r"\bWAZZUP\b"),
    ("BUHBYE", r"\bBUHBYE\b"),
    ("NOT", r"\bNOT\b"),

    # identifiers
    ("IDENTIFIER", r"[A-Za-z][_A-Za-z0-9]*")
]

# keyword classification
classification = {
    #code delimiters
    "HAI": "Code Delimiter",
    "KTHXBYE": "Code Delimiter",

    #variable delimeter
    "WAZZUP": "Variable Delimeter",
    "BUHBYE": "Variable Delimeter",

    #variable
    "I_HAS_A": "Variable Declaration",
    "ITZ": "Variable Assignment",
    "R": "Variable Assignment",

    #identifier
    "IDENTIFIER": "Identifier",

    #IO
    "VISIBLE": "Output Keyword",
    "GIMMEH": "Input Keyword",

    #literals
    "NUMBR": "Literal",
    "NUMBAR": "Literal",
    "YARN": "Literal",
    "TROOF": "Literal",
    "TYPE": "Literal",

    #operations (arithmetic, relational, boolean, multiple, comparison, string)
    "SUM_OF": "Arithmetic Operation",
    "DIFF_OF": "Arithmetic Operation",
    "PRODUKT_OF": "Arithmetic Operation",
    "QUOSHUNT_OF": "Arithmetic Operation",
    "MOD_OF": "Arithmetic Operation",
    "BIGGR_OF": "Relational Operation",
    "SMALLR_OF": "Relational Operation",
    "BOTH_OF": "Boolean Operation",
    "EITHER_OF": "Boolean Operation",
    "WON_OF": "Boolean Operation",
    "NOT": "Boolean Operation",
    "ANY_OF": "Multiple Operation",
    "ALL_OF": "Multiple Operation",
    "BOTH_SAEM": "Comparison Operation",
    "DIFFRINT": "Comparison Operation",
    "SMOOSH": "String Operation",

    #type conversion
    "MAEK": "Type Conversion",
    "IS_NOW_A": "Type Conversion",

    #other delimiters
    "A": "Type Delimiter",
    "AN": "Data Delimiter",

    #control flow
    "NOOB": "Conditional Delimiter",
    "O_RLY": "Conditional Delimiter",
    "YA_RLY": "Conditional Delimiter",
    "MEBBE": "Conditional Delimiter",
    "NO_WAI": "Conditional Delimiter",
    "WTF": "Case Delimiter",
    "OMG": "Case Delimiter",
    "OMGWTF": "Case Delimiter",

    #loops
    "IM_IN_YR": "Loop Delimiter",
    "UPPIN_YR": "Loop Increment",
    "NERFIN_YR": "Loop Decrement",
    "YR": "Loop Delimiter",
    "TIL": "Loop Condition",
    "WILE": "Loop Condition",
    "IM_OUTTA_YR": "Loop End Delimiter",
    "OIC": "Control Flow End Delimiter",

    #functions
    "HOW_IZ_I": "Function Delimiter",
    "IF_U_SAY_SO": "Function End Delimiter",
    "FOUND_YR": "Function Return",
    "I_IZ": "Function Call",
    "MKAY": "Function Parameter Delimiter",

    #comments
    "COMMENT": "Comment",
    "OBTW": "Start of Comment Block",
    "TLDR": "End of Comment Block",

    "LINEBREAK": "Linebreak"
}

allPatterns = []    # list to hold all grouped patterns

# for each pair in keywordSpecs, create a group
for keywordName, regex in keywordSpecs:
    grouped = "(?P<" + keywordName + ">" + regex + ")"
    allPatterns.append(grouped)

# combine all patterns into one
combinePatterns = "|".join(allPatterns)

# compile the combined regex
mainPattern = re.compile(combinePatterns)

def readFile(filepath):
    # read the file
    try:
        with open(filepath, "r") as file:
            myFile = file.read()
        return myFile
    except FileNotFoundError:
        print(f"Error: File '{filepath}' not found.")
        return None

def tokenize(myFile):
    tokens = []
    matches = mainPattern.finditer(myFile)

    comment_block = False       # flag for checking if lines are inside a comment block

    for match in matches:
        tokType = match.lastgroup
        tokVal = match.group()

        # if token is comment
        if tokType == "COMMENT":
            continue

        # check if lines are in comment block, skip if yes
        if comment_block:
            # comment block done when TLDR is read
            if tokType == "TLDR":
                comment_block = False
            continue

        # start reading as comment block
        if tokType == "OBTW":
            comment_block = True
            continue

        tokVal = tokVal.strip()
        tokens.append((tokType, tokVal))

    return tokens


def classify(tokType, tokVal):
    if tokType == "YARN":
        return None 
    elif tokType in classification:
        return classification[tokType]
    else:
        return "Unknown classification"


def printToken(tokens):
    print(f"\n{'Lexeme':<20}Classification")
    print("---------------------------------")

    for tokType, tokVal in tokens:
        if tokType == "YARN":
            # special handling for YARN (string)
            # YARN contains quotes, print them separately
            print(f"{'\"':<20}String Delimiter")
            actualString = tokVal.strip('"')
            if actualString:
                print(f"{actualString:<20}Literal(2)") # debugging purposes 
            print(f"{'\"':<20}String Delimiter")
        else:
            classifyName = classify(tokType, tokVal)
            print(f"{tokVal:<20}{classifyName}")


# def main():
#     filepath = "project-testcases/01_variables.lol"

#     myFile = readFile(filepath)
#     if myFile is None:
#         return 

#     tokens = tokenize(myFile)

#     printToken(tokens)

# main()

# https://www.geeksforgeeks.org/python/re-compile-in-python/
# https://www.w3schools.com/python/python_regex.asp
# https://www.geeksforgeeks.org/python/re-match-in-python/



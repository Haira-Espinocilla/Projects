# CMSC-124-Project

# How to run the program:

### 1. Setup:

#### Install ttkbootstrap
Open your terminal or command prompt and run the following command to install `ttkbootstrap`

```bash
pip install ttkbootstrap
```

### 2. Run the program:

Run the `finalproj_gui.py` file to start the program.
package com.example.travelplanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
